﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Mangement_System
{
    class Project
    {
        public int projectId, departmentId, employeeId;
        public string projectName;

        public Project(int projectId, int departmentId, int employeeId, string projectName)
        {
            this.projectId = projectId;
            this.departmentId = departmentId;
            this.employeeId = employeeId;
            this.projectName = projectName;
        }

        public string OutputStream()
        {
            return projectId.ToString() + "," + projectName + "," + departmentId.ToString() + "," + employeeId.ToString();
        }
    }
}
