﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Mangement_System
{
    class Employee
    {
        public int employeeId, departmentId;
        public string employeeName, email, phone;

        public Employee(int employeeId, string phone, int departmentId, string employeeName, string email)
        {
            this.employeeId = employeeId;
            this.phone = phone;
            this.departmentId = departmentId;
            this.employeeName = employeeName;
            this.email = email;
        }
        public string OutputString()
        {
            return employeeId.ToString() + "," + employeeName + "," + email + "," + phone + "," + departmentId.ToString();
        }
    }
}
