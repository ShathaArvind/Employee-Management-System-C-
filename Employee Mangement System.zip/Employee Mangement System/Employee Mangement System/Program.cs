﻿using System;
using System.IO;

namespace Employee_Mangement_System
{
    class Program
    {
        static void Main(string[] args)
        {
            string employeeFileName = @"C:\Users\Arvind\Desktop\C# Project Files\EmpRcord.txt";
            string departmentFileName = @"C:\Users\Arvind\Desktop\C# Project Files\DeptRecord.txt";
            string projectFileName = @"C:\Users\Arvind\Desktop\C# Project Files\ProjRecord.txt";
            while (true)
            {
                Console.WriteLine("1. To Insert Employee Records");
                Console.WriteLine("2. To Insert Department Records");
                Console.WriteLine("3. To Insert Project Records");
                Console.WriteLine("4. To get Employee details by Dept Name");
                Console.WriteLine("5. To Enter Employee id to get details");
                Console.WriteLine("6. Print Projects based on Department");
                Console.WriteLine("7. Exit");
                Console.WriteLine("|_-_-_-__-_-__-_-__-_-__-_-__-_-__-_-__-_-|");
                Console.WriteLine("Enter your Choice");
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Employee employee = ReadAndGetNewEmployee();
                        FileStream employeeFileStream = new FileStream(employeeFileName, FileMode.Append, FileAccess.Write);
                        StreamWriter employeeStreamWriter = new StreamWriter(employeeFileStream);
                        employeeStreamWriter.WriteLine(employee.OutputString());
                        employeeStreamWriter.Close();
                        break;
                    case 2:
                        Department department = ReadAndGetNewDepatment();
                        FileStream departmentFileStream = new FileStream(departmentFileName, FileMode.Append, FileAccess.Write);
                        StreamWriter departmentStreamWriter = new StreamWriter(departmentFileStream);
                        departmentStreamWriter.WriteLine(department.OutputStream());
                        departmentStreamWriter.Close();
                        break;
                    case 3:
                        Project project = ReadAndGetNewProject();
                        FileStream projectFileStream = new FileStream(projectFileName, FileMode.Append, FileAccess.Write);
                        StreamWriter projectStreamWriter = new StreamWriter(projectFileStream);
                        projectStreamWriter.WriteLine(project.OutputStream());
                        projectStreamWriter.Close();
                        break;
                    case 4:
                        /*
                            1. Read department name
                            2. get department Id based on department name from DepartmentFile
                            3. get employee from EmployeeFile based on departmentId
                        */
                        Console.Write("Enter department name: ");
                        string departmentName = Console.ReadLine();

                        // 2. get deapartment Id based on department name from DepartmentFile
                        int departmentId = -1;
                        if (File.Exists(departmentFileName))
                        {
                            string[] lines = File.ReadAllLines(departmentFileName);
                            foreach (string line in lines)
                            {
                                string[] words = line.Split(',');
                                if (words[1].Equals(departmentName))
                                {
                                    departmentId = int.Parse(words[0]);
                                }
                            }
                        }
                        // 3. get employee from EmployeeFile based on departmentId
                        if (departmentId != -1)
                        {
                            string[] lines = File.ReadAllLines(employeeFileName);
                            foreach (string line in lines)
                            {
                                string[] words = line.Split(',');
                                if (int.Parse(words[4]) == departmentId)
                                {
                                    Console.WriteLine(words[0] + " " + words[1] + " " + words[2] + " " + words[3] + " " + words[4]);
                                }
                            }
                        }
                        break;
                    case 5:
                        /*
                            1. Read employeeId
                            2. get employee based on employeeId
                            3. get project based on employeeId
                        */
                        Console.Write("Enter employee id: ");
                        int employeeId = int.Parse(Console.ReadLine());

                        // 2. get employee based on employeeId
                        if (File.Exists(employeeFileName))
                        {
                            string[] lines = File.ReadAllLines(employeeFileName);
                            foreach (string line in lines)
                            {
                                Console.WriteLine("Employees:");
                                string[] words = line.Split(',');
                                if (int.Parse(words[0]) == employeeId)
                                {
                                    Console.WriteLine(words[0] + " " + words[1] + " " + words[2] + " " + words[3] + " " + words[4]);
                                }
                            }
                        }
                        // 3.get project based on employeeId
                        if (File.Exists(projectFileName))
                        {
                            string[] lines = File.ReadAllLines(projectFileName);
                            foreach (string line in lines)
                            {
                                Console.WriteLine("Projects:");
                                string[] words = line.Split(',');
                                if (int.Parse(words[3]) == employeeId)
                                {
                                    Console.WriteLine(words[0] + " " + words[1] + " " + words[2] + " " + words[3]);
                                }
                            }
                        }
                        break;
                    case 6:
                        /*
                            1. Read departmentName
                            2. get departmentid based on departmentName
                            3. get project based on departmentId
                        */
                        Console.Write("Enter department name: ");
                        string prodepartmentName = Console.ReadLine();
                        int projectDepartmentId = -1;
                        if (File.Exists(departmentFileName))
                        {
                            string[] lines = File.ReadAllLines(departmentFileName);
                            foreach (string line in lines)
                            {
                                string[] words = line.Split(',');
                                if (words[1].Equals(prodepartmentName))
                                {
                                    projectDepartmentId = int.Parse(words[0]);
                                }
                            }
                        }
                        if (projectDepartmentId != -1)
                        {
                            string[] lines = File.ReadAllLines(projectFileName);
                            foreach (string line in lines)
                            {
                                string[] words = line.Split(',');
                                if (int.Parse(words[2]) == projectDepartmentId)
                                {
                                    Console.WriteLine(words[0] + " " + words[1] + " " + words[2] + " " + words[3]);
                                }
                            }
                        }

                        break;
                    case 7:

                        return;
                }
            }
        }
        static Employee ReadAndGetNewEmployee()
        {
            Console.Write("Enter Employee Id = ");
            int employeeId = int.Parse(Console.ReadLine());

            Console.Write("Enter Employee Name = ");
            string employeeName = Console.ReadLine();

            Console.Write("Enter Employee Email = ");
            string email = Console.ReadLine();

            Console.Write("Enter Employee phone number = ");
            string phone = Console.ReadLine();

            Console.Write("Enter Employee department id = ");
            int departmentId = int.Parse(Console.ReadLine());

            return new Employee(employeeId, phone, departmentId, employeeName, email);
        }
        static Department ReadAndGetNewDepatment()
        {
            Console.Write("Enter Department Id: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Enter Department Name: ");
            string departmentName = Console.ReadLine();

            Console.Write("Enter number of projects: ");
            int numberOfProjects = int.Parse(Console.ReadLine());

            return new Department(departmentName, id, numberOfProjects);
        }

        static Project ReadAndGetNewProject()
        {
            Console.Write("Enter project id: ");
            int projectId = int.Parse(Console.ReadLine());

            Console.Write("Enter department id: ");
            int projectDepartmentId = int.Parse(Console.ReadLine());

            Console.Write("Enter employee id: ");
            int projectEmployeeId = int.Parse(Console.ReadLine());

            Console.Write("Enter project Name: ");
            string projectName = Console.ReadLine();

            return new Project(projectId, projectDepartmentId, projectEmployeeId, projectName);
        }
    }
}
