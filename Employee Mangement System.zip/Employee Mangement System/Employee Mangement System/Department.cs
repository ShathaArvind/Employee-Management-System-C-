﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Mangement_System
{
    class Department
    {
        public string departmentName;
        public int departmentId, numberOfProjects;

        public Department(string departmentName, int departmentId, int numberOfProjects)
        {
            this.departmentName = departmentName;
            this.departmentId = departmentId;
            this.numberOfProjects = numberOfProjects;
        }

        public string OutputStream()
        {
            return departmentId.ToString() + "," + departmentName + "," + numberOfProjects.ToString();
        }
    }
}
